import React from 'react'

export default function Orders() {
  return (
    <div>Orders</div>
  )
}
