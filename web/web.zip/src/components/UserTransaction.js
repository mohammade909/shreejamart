import React, { useState, useEffect } from "react";

import {
  Button,
  CardHeader,
  Input,
  Typography,
  Card,
  CardContent,
  Grid,
  TextField,
  MenuItem,
} from "@mui/material";
import ReactPaginate from "react-paginate";
import { Calendar, DollarSign, CreditCard, AlertCircle } from "lucide-react";
import { fetchTransactionsByUserId } from "../redux/transactionSlice";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
const UserTransactions = () => {
  const dispatch = useDispatch();
  const { id } = useParams();
  const { auth } = useSelector((state) => state.auth);

  const userId = auth?.user_type === "admin" ? id : auth.user_id;

  const { transactions, pagination } = useSelector(
    (state) => state.transactions
  );
  const [filters, setFilters] = useState({
    startDate: "",
    endDate: "",
    status: "",
    search: "",
    sort: "newest",
    limit: 10,
  });
  const [page, setPage] = useState(1);
  useEffect(() => {
    dispatch(fetchTransactionsByUserId({ userId, page, filters }));
  }, [page, filters]);

  // Calculate statistics
  const stats = {
    totalAmount: transactions.reduce((sum, t) => sum + parseFloat(t.amount), 0),
    completed: transactions.filter((t) => t.status === "completed").length,
    pending: transactions.filter((t) => t.status === "pending").length,
    failed: transactions.filter((t) => t.status === "failed").length,
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "failed":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  const handleFilterChange = (e) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value,
    });
  };

  const handlePageChange = ({ selected }) => {
    setPage(selected + 1);
  };
  return (
    <div className="p-2 space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4  border border-gray-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-2">
                  Total Wallet Amount
                </p>
                <p className="text-xl font-semibold">
                  ₹{stats.totalAmount.toFixed(2)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4  border border-gray-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium mb-2 text-gray-600">Completed</p>
                <p className="text-xl font-semibold">{stats.completed}</p>
              </div>
              <CreditCard className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4  border border-gray-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-2">Pending</p>
                <p className="text-xl font-semibold">{stats.pending}</p>
              </div>
              <Calendar className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4  border border-gray-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-2">Failed</p>
                <p className="text-xl font-semibold">{stats.failed}</p>
              </div>
              <AlertCircle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Filters
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                fullWidth
                type="date"
                label="Date From"
                name="startDate"
                value={filters.startDate}
                onChange={handleFilterChange}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                fullWidth
                type="date"
                label="Date To"
                name="endDate"
                value={filters.endDate}
                onChange={handleFilterChange}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                fullWidth
                select
                label="Status"
                name="status"
                value={filters.status}
                onChange={handleFilterChange}
              >
                <MenuItem value="">All Status</MenuItem>
                <MenuItem value="pending">Pending</MenuItem>
                <MenuItem value="completed">Approved</MenuItem>
                <MenuItem value="cancelled">Rejected</MenuItem>
              </TextField>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <TextField
                fullWidth
                select
                label="Limit"
                name="limit"
                value={filters.limit}
                onChange={handleFilterChange}
              >
                <MenuItem value={5}>5</MenuItem>
                <MenuItem value={10}>10</MenuItem>
                <MenuItem value={20}>20</MenuItem>
                <MenuItem value={50}>50</MenuItem>
                <MenuItem value={100}>100</MenuItem>
              </TextField>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Transactions Table */}
      <Card>
        <CardHeader>
          <h2>Transactions</h2>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b bg-black text-sm">
                  <th className="px-4 py-3 text-left text-white font-medium">TXN</th>
                  <th className="px-4 py-3 text-left text-white font-medium">Date</th>
                  <th className="px-4 py-3 text-left text-white font-medium">Description</th>
                  <th className="px-4 py-3 text-left text-white font-medium">Amount</th>
                  <th className="px-4 py-3 text-left text-white font-medium">Status</th>
                  <th className="px-4 py-3 text-left text-white font-medium">Payment Method</th>
                </tr>
              </thead>
              <tbody>
                {transactions.length > 0 ? (
                  transactions?.map((transaction) => (
                    <tr key={transaction.transaction_id} className="border-b">
                      <td className="px-4 py-2">{transaction.txn_no}</td>
                      <td className="px-4 py-2">
                        {new Date(
                          transaction.transaction_date
                        ).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-2">{transaction.description}</td>
                      <td className="px-4 py-2">₹{transaction.amount}</td>
                      <td className="px-4 py-2">
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${getStatusColor(
                            transaction.status
                          )}`}
                        >
                          {transaction.status}
                        </span>
                      </td>
                      <td className="px-4 py-2">
                        {transaction.payment_method}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                  <td colSpan={6} className="px-6 py-4 text-base text-red-400  text-center  border border-gray-300">
                404 No transaction found!
                </td>
                </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {pagination?.totalPages > 1 && (
            <div className="mt-4">
              <ReactPaginate
                previousLabel={"← Previous"}
                nextLabel={"Next →"}
                breakLabel={"..."}
                pageCount={pagination.totalPages}
                marginPagesDisplayed={2}
                pageRangeDisplayed={5}
                onPageChange={handlePageChange}
                containerClassName={"flex justify-center gap-2"}
                activeClassName={"text-blue-500 font-bold"}
                pageClassName={
                  "px-3 py-1 border rounded hover:bg-gray-200 cursor-pointer"
                }
              />
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default UserTransactions;
