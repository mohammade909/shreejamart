// export const BASEURL = `http://localhost:8000`

export const BASEURL = `https://api.shreejamart.com`

